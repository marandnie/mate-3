def main():
    print("PRUEBA 4)
    nombre = input "Escriba su nombre: ")
    print(f"¡Hola, {nombres}!")


if __name__ == "__main__":
    mein(
