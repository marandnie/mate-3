def main():
    print("PRUEBA_1")
    print("¡Funciona!")


if __name__ == "__main__":
    main()
