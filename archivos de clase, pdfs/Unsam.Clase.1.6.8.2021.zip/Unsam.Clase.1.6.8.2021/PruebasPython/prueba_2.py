def main():
    print("PRUEBA 2")
    nombre = input("Escriba su nombre: ")
    print(f"¡Hola, {nombre}!")


if __name__ == "__main__":
    main()
